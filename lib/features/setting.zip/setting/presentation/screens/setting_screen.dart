import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:saving_coop_showcase/core/bloc/locale/locale_bloc.dart';

import '../widgets/acc_setting_widget.dart';
import '../widgets/app_setting_widget.dart';
import '../widgets/other_setting_widget.dart';
import '../widgets/user_setting_widget.dart';

class SettingScreen extends StatelessWidget {
  const SettingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
        create: (_) => LocaleBloc(),
        child: BlocBuilder<LocaleBloc, LocaleState>(builder: (context, state) {
          return Scaffold(
            // appBar: titleWidget(context),
            body: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  UserSettingwidget(),
                  AccSettingwidget(),
                  AppSettingwidget(),
                  OtherSettingwidget(),
                ],
              ),
            ),
          );
        }));
  }
}
