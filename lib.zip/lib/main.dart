import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'core/routes/app_routes.dart';
import 'core/bloc/auth/auth_bloc.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});
  static final GlobalKey<NavigatorState> navigatorKey =
      GlobalKey<NavigatorState>();
  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      //* -- In main.dart, only import the necessary global files. --
      providers: [BlocProvider(create: (context) => AuthBloc())],
      child: BlocListener<AuthBloc, AuthState>(
        // 3. ดักฟังสถานะ Auth ทั่วทั้งแอปที่จุดนี้จุดเดียว
        listener: (context, state) {
          if (state.status == AuthStatus.unauthenticated) {
            // ถ้าหลุดล็อกอิน ให้ดีดไปหน้า Login และล้าง Stack หน้าจอทั้งหมด
            navigatorKey.currentState?.pushNamedAndRemoveUntil(
              AppRoutes.login,
              (route) => false,
            );
          } else if (state.status == AuthStatus.authenticated) {
            // ถ้าล็อกอินสำเร็จ ให้ไปหน้า Home
            navigatorKey.currentState?.pushNamedAndRemoveUntil(
              AppRoutes.home,
              (route) => false,
            );
          }
        },
        child: MaterialApp(
          title: 'Production App',
          debugShowCheckedModeBanner: false,
          navigatorKey: navigatorKey,
          // เรียกใช้การตั้งค่า Route ที่เราแยกไว้
          initialRoute: AppRoutes.home,
          onGenerateRoute: AppRoutes.onGenerateRoute,
        ),
      ),
    );
  }
}
