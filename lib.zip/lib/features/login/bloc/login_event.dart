part of 'login_bloc.dart';

abstract class LoginEvent {}

class LoginSubmitted extends LoginEvent {
  final String username;
  final String password;

  LoginSubmitted({required this.username, required this.password});
}

// (Option) ถ้าต้องการทำ Real-time validation ขณะพิมพ์
class LoginUsernameChanged extends LoginEvent {
  final String username;
  LoginUsernameChanged(this.username);
}