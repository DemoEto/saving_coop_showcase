import 'package:flutter_bloc/flutter_bloc.dart';
part 'login_event.dart';
part 'login_state.dart';

class LoginBloc extends Bloc<LoginEvent, LoginState> {
  // ในโปรเจกต์จริง ควรสร้าง LoginRepository มาจัดการเรื่องยิง API
  // final LoginRepository _loginRepository;

  LoginBloc() : super(LoginInitial()) {
    on<LoginSubmitted>(_onLoginSubmitted);
  }

  Future<void> _onLoginSubmitted(
    LoginSubmitted event,
    Emitter<LoginState> emit,
  ) async {
    emit(LoginLoading());

    try {
      // จำลองการยิง API (ในงานจริงให้เรียกผ่าน Repository)
      await Future.delayed(const Duration(seconds: 2));

      if (event.username == "admin" && event.password == "1234") {
        emit(LoginSuccess("dummy_token_123"));
      } else {
        emit(LoginFailure("ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง"));
      }
    } catch (e) {
      emit(LoginFailure("เกิดข้อผิดพลาด: ${e.toString()}"));
    }
  }
}