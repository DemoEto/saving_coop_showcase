import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:saving_coop_showcase/core/bloc/auth/auth_bloc.dart';

import '../../bloc/login_bloc.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  TextEditingController? userController = TextEditingController();
  TextEditingController? passController = TextEditingController();

  @override
  void dispose() {
    super.dispose();
    userController?.dispose();
    passController?.dispose();
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('login')),
      body: BlocConsumer<LoginBloc, LoginState>(
        // ส่วนของ Listener สำหรับสั่งงาน (Action)
        listener: (context, state) {
          if (state is LoginSuccess) {
            // บอก Global Auth ว่าล็อกอินผ่านแล้ว
            context.read<AuthBloc>().add(AuthStatusChanged(true));

            // เปลี่ยนหน้า
            Navigator.pushReplacementNamed(context, '/home');
          }

          if (state is LoginFailure) {
            ScaffoldMessenger.of(
              context,
            ).showSnackBar(SnackBar(content: Text(state.error)));
          }
        },
        // ส่วนของ Builder สำหรับวาด UI
        builder: (context, state) {
          return Column(
            children: [
              TextField(controller: userController),
              TextField(controller: passController),
              const SizedBox(height: 20),

              // เช็คสถานะ Loading เพื่อแสดง UI ที่เหมาะสม
              state is LoginLoading
                  ? const CircularProgressIndicator()
                  : ElevatedButton(
                      onPressed: () {
                        context.read<LoginBloc>().add(
                          LoginSubmitted(
                            username:userController!.text,
                            password:passController!.text,
                          ),
                        );
                      },
                      child: const Text('Login'),
                    ),
            ],
          );
        },
      ),
    );
  }
}
