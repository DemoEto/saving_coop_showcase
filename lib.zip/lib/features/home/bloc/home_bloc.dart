import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:saving_coop_showcase/core/bloc/auth/auth_bloc.dart';

part 'home_event.dart';
part 'home_state.dart';

class HomeBloc extends Bloc<HomeEvent, HomeState> {
  final AuthBloc _authBloc;
  late final StreamSubscription _authSubscription;
  // HomeModel? homeModel;

  HomeBloc({required AuthBloc authBloc}) :_authBloc = authBloc, super(HomeInitialState()) {
    // final HomeProvider homeProvider = HomeProvider();
    // final AppStorage storage = AppStorage();

    _authSubscription = _authBloc.stream.listen((authState) {
      if (authState.status == AuthStatus.unauthenticated) {
        add(HomeInitEvent());
      }
    });


    // on<HomeFetchEvent>((event, emit) async {
    //   log('event: $event');

    //   if (event.showLoading) emit(HomeLoadingState());

    //   final authState = authBloc.state;

    //   log('authState: $authState');

    //   if (authState is AuthLoggedInState) {
    //     final accessToken = authState.accessToken;
    //     final refreshToken = authState.refreshToken;
    //     // log('accessToken: $accessToken');
    //     Map<String, dynamic> params = {};

    //     final depositNo = await storage.getHomeAccountDeposit();
    //     final loanNo = await storage.getHomeAccountLoan();
    //     if (depositNo != 'all') {
    //       params.addAll({'home_deposit_account': depositNo});
    //     }
    //     if (loanNo != 'all') {
    //       params.addAll({'home_loan_account': loanNo});
    //     }

    //     final res = await homeProvider.fetchHomeMenu(
    //       accessToken,
    //       refreshToken,
    //       params,
    //     );

    //     context.read<SettingViewBalanceBloc>().add(
    //       SettingViewBalanceFetchEvent(showLoading: false),
    //     );

    //     // unexpected error case
    //     if (res?.statusCode != 200) {
    //       // dio error case
    //       if (res?.data['RESPONSE_MESSAGE'].runtimeType == String) {
    //         return emit(HomeErrorState(message: res!.data['RESPONSE_MESSAGE']));
    //       }

    //       return emit(HomeErrorState());
    //     }

    //     if (res?.data != null && res?.data is Map<String, dynamic>) {
    //       try {
    //         final data = res?.data;

    //         if (data == null || data is! Map<String, dynamic>) {
    //           emit(HomeErrorState(message: 'Data is empty'));
    //           return;
    //         }

    //         // final homeData = HomeModel.fromJson(data);

    //         emit(HomeLoadedState());
    //         // emit(HomeLoadedState(homeData: homeData));
    //       } catch (e, s) {
    //         log('Home parse error: $e');
    //         log('$s');
    //         emit(HomeErrorState(message: 'Failed to load home data'));
    //       }
    //     } else {
    //       emit(HomeErrorState(message: 'Invalid response data'));
    //     }
    //   }
    // });

    // clear all and reinitialize data
    on<HomeInitEvent>((event, emit) {
      // log('event: $event');
      emit(HomeInitialState());
    });
  }

  @override
  Future<void> close() {
    _authSubscription.cancel(); // อย่าลืม cancel เมื่อ bloc ปิด
    return super.close();
  }
}
