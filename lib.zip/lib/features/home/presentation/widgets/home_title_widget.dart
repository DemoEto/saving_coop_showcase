import 'package:flutter/material.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

// import 'package:sko_flutter/notification/presentation/notification_page.dart';
// import 'package:sko_flutter/setting/presentation/setting_page.dart';
// import 'package:sko_flutter/profile/presentation/profile_page.dart';

class HomeTitleWidget extends StatelessWidget implements PreferredSizeWidget {
  final String? userName;
  final String? userSurname;
  final String? avatarPath;
  // final UserModel? user;
  final VoidCallback? onProfileTap;
  final VoidCallback? onNotificationTap;
  final VoidCallback? onSettingTap;
  final VoidCallback? onLogoutTap;

  const HomeTitleWidget({
    super.key,
    this.userName,
    this.userSurname,
    this.avatarPath,
    // this.user,
    this.onProfileTap,
    this.onNotificationTap,
    this.onSettingTap,
    this.onLogoutTap,
  });

  @override
  Size get preferredSize => const Size.fromHeight(100);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: const BoxDecoration(
        // color: Color.fromARGB(255, 255, 255, 255),
        // color: Color(0xFF4A7FD8),
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(20),
          bottomRight: Radius.circular(20),
        ),
      ),
      child: SafeArea(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              flex: 1,
              child: InkWell(
                onTap: onProfileTap,
                child: Row(
                  // mainAxisSize: MainAxisSize.max,
                  children: [
                    Icon(LucideIcons.circleUser)
                    // CustomCircleAvatar(path: user?.avatarPath, radius: 25),
                  ],
                ),
              ),
            ),
            Expanded(
              flex: 2,
              child: Icon(LucideIcons.circleUser)
              // child: const IconOrImage(
              //   path: "${AppConfig.imageAssetPath}/auth/coop_logo.webp",
              //   heightPortion: 0.05,
              // ),
            ),
            Expanded(
              flex: 1,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end, // ชิดขวา
                mainAxisSize: MainAxisSize.min,
                children: [
                  // ใช้สไตล์ปุ่มที่ไม่มี padding ส่วนเกินจริงๆ
                  SizedBox(
                    width: 32, // กำหนดขนาดพื้นที่ปุ่มให้ชัดเจน
                    child: IconButton(
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                      style: IconButton.styleFrom(
                        tapTargetSize: MaterialTapTargetSize
                            .shrinkWrap, // ลดพื้นที่กดให้เล็กลงตามไอคอน
                      ),
                      icon: const Icon(
                        LucideIcons.bell,
                        color: Colors.black54,
                        size: 24,
                      ),
                      onPressed: onNotificationTap,
                    ),
                  ),
                  const SizedBox(width: 12), // เว้นระยะห่างระหว่างปุ่มเล็กน้อย
                  SizedBox(
                    width: 32,
                    child: IconButton(
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                      style: IconButton.styleFrom(
                        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      ),
                      icon: const Icon(
                        LucideIcons.logOut,
                        color: Colors.black54,
                        size: 24,
                      ),
                      onPressed: onLogoutTap,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
