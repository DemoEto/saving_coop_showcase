import 'package:flutter/material.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

import '../theme/colors.dart';

class CustomCircleAvatar extends StatelessWidget {
  final String? path;
  // final Widget? placeholder;
  final double radius;
  final bool isCamera;
  final void Function()? onTap;
  final Color? borderColor;

  const CustomCircleAvatar({
    super.key,
    this.path,
    // this.placeholder = const IconOrImage(
    //   path: '${AppConfig.iconAssetPath}/memberinfo_user.svg',
    //   heightPortion: 1,
    // ),
    required this.radius,
    this.isCamera = false,
    this.onTap,
    this.borderColor = AppColors.white,
  });

  @override
  Widget build(BuildContext context) {
    // TODO: Fix Inkwell no effect later
    return InkWell(
      customBorder: const CircleBorder(),
      onTap: onTap,
      child: Stack(
        children: [
          Material(
            elevation: 0,
            shape: const CircleBorder(),
            child: CircleAvatar(
              radius: radius,
              backgroundColor: borderColor,
              child: CircleAvatar(
                radius: radius * 0.95,
                backgroundColor: AppColors.white,
                child: ClipRRect(
                        borderRadius: BorderRadius.circular(radius),
                        child: Container(
                          // to force image fit with border
                          width: double.infinity,
                          decoration: BoxDecoration(
                            color: Colors.grey.shade400,
                          ),
                          child: Icon(LucideIcons.circleUser)
                        ),
                      )
                // child: path != null
                //     ? ClipRRect(
                //         borderRadius: BorderRadius.circular(radius),
                //         child: Container(
                //           // to force image fit with border
                //           width: double.infinity,
                //           decoration: BoxDecoration(
                //             color: Colors.grey.shade400,
                //           ),
                          // child: IconOrImage(
                          //   path: path!,
                          //   heightPortion: 1,
                          //   fit: BoxFit.cover,
                          // ),
                //         ),
                //       )
                //     : placeholder,
              ),
            ),
          ),
          isCamera
              ? Positioned(
                  right: 0,
                  bottom: 0,
                  child: Material(
                    elevation: 2,
                    shape: const CircleBorder(),
                    child: CircleAvatar(
                      backgroundColor: Colors.white,
                      radius: radius * 0.3,
                      child: Icon(
                        Icons.camera_alt_rounded,
                        color: AppColors.greyDark,
                        size: radius * 0.45,
                      ),
                    ),
                  ),
                )
              : const SizedBox.shrink(),
        ],
      ),
    );
  }
}
