part of 'auth_bloc.dart';

abstract class AuthEvent {}

class AuthAppStarted extends AuthEvent {} // เช็คตอนเปิดแอปครั้งแรก

class AuthStatusChanged extends AuthEvent {
  final bool isAuthenticated;
  AuthStatusChanged(this.isAuthenticated);
}

class AuthLogoutRequested extends AuthEvent {}

class AuthLoginEvent extends AuthEvent {
  final String username;
  final String password;

  AuthLoginEvent({
    required this.username,
    required this.password,
  });
}
