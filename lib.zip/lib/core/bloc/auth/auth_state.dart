part of 'auth_bloc.dart';

class AuthState {
  final AuthStatus status;
  AuthState({this.status = AuthStatus.unknown});
}

enum AuthStatus { unknown, authenticated, unauthenticated }

class AuthUnauthorized extends AuthState {}

enum AuthErrorCase {
  login,
  forgotPassword,
  checkMembership,
  register,
  checkAndUpdatePin,
  checkPinLogin,
  reactiveSignIn,
  resetPin,
  dioLevelError,
  baseError,
}

class AuthInitialState extends AuthState {}

class AuthLoggedInState extends AuthState {
  final String accessToken;
  final String refreshToken;
  final bool isPin;
  final bool isPinPass;
  // final UserModel? user;

  AuthLoggedInState({
    required this.accessToken,
    required this.refreshToken,
    required this.isPin,
    this.isPinPass = false,
    // required this.user,
  });
}
