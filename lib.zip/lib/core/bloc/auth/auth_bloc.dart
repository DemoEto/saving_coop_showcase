import 'package:flutter_bloc/flutter_bloc.dart';

part 'auth_event.dart';
part 'auth_state.dart';

class AuthBloc extends Bloc<AuthEvent, AuthState> {
  AuthBloc() : super(AuthState()) {
    on<AuthAppStarted>((event, emit) async {
      // จำลองการเช็ค Token ในเครื่อง (เช่นจาก Secure Storage)
      await Future.delayed(const Duration(seconds: 1));
      emit(AuthState(status: AuthStatus.unauthenticated));
    });

    on<AuthStatusChanged>((event, emit) {
      emit(AuthState(
        status: event.isAuthenticated ? AuthStatus.authenticated : AuthStatus.unauthenticated
      ));
    });

    on<AuthLogoutRequested>((event, emit) {
      // ลบ Token แล้วเปลี่ยนสถานะ
      emit(AuthState(status: AuthStatus.unauthenticated));
    });
  }
}