import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:saving_coop_showcase/core/bloc/auth/auth_bloc.dart';

import '../../features/home/home.dart';
import '../../features/login/login.dart';

class AppRoutes {
  static const String home = '/';
  static const String login = '/login';

  static Route onGenerateRoute(RouteSettings settings) {
    switch (settings.name) {
      case home:
        return MaterialPageRoute(
          builder: (context) {
            final authBloc = context.read<AuthBloc>();
            return BlocProvider(
              create: (context) => HomeBloc(authBloc: authBloc),
              child: const HomeScreen(),
            );
          },
        );
      case login:
        return MaterialPageRoute(
          // ตัวอย่างการฉีด BLoC เข้าไปเฉพาะหน้าที่ใช้งาน
          builder: (_) => BlocProvider(
            create: (context) => LoginBloc(),
            child: const LoginScreen(),
          ),
        );
      default:
        return MaterialPageRoute(
          builder: (_) =>
              const Scaffold(body: Center(child: Text('Page not found'))),
        );
    }
  }
}
